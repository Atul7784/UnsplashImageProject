//
//  CollectionViewCell.swift
//  Unplash Image
//
//  Created by Atul Kumar Verma on 16/04/24.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var imageView: UIImageView!
    
}
